BounceGame
==========

Alpha Version XNA Framework 


The player has 3 lives and must hit all the blocks to win. 


Bugs:

The ball sometimes goes through the blocks 


 
In the near future I will add a score and fix collision bugs. Eventually I will add more sounds and gameplay. 




Install
=======

	1. Run setup wizard  



Controls
========


Space bar launches ball


Arrow keys move player





